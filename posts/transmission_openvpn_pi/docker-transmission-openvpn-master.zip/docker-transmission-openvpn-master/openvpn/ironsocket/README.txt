Original OVPN files were downloaded from IronSocket at https://ironsocket.com/network#ovpn and modified as follows:

1. Updated 'auth-user-pass' to read login credentials from a file.
2. Updated 'ca', 'cert', 'key' and 'tls-cert' to read from files to simplify future maintenance.
3. Added default.ovpn pointing to United-Kingdom.ovpn.

Last updated: 11 May 2018
